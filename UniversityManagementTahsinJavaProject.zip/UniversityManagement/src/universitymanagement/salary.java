package universitymanagement;
interface salary {
 public  String Annualincome();
  public String toString();
}
