package universitymanagement;

class lblSrtudentDetails {

}
